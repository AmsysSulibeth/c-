﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iguales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            txt4.Clear();
            txtresultado.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b, c, d;
            char result;
            a = Convert.ToInt32(txt1.Text);
            b = Convert.ToInt32(txt2.Text);
            c = Convert.ToInt32(txt3.Text);
            d = Convert.ToInt32(txt4.Text);

            if(d == a)
            {
                Console.WriteLine("El primero");

            } else if (d == b)
            {
                Console.WriteLine("El segundo");
               

            } else if (d == c)
            {
                Console.WriteLine("El tercero");
                

            } else
            {
                Console.WriteLine("Ninguno");
                
            }

            txtresultado.Text = Convert.ToString(d);
        }
    }
}
