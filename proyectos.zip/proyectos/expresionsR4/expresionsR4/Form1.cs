﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace expresionsR4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btsalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btlimpiar_Click(object sender, EventArgs e)
        {
            TxtA.Clear();
            Txtb.Clear();
            Txtc.Clear();
            Txtd.Clear();
            Txtresultado.Clear();
            TxtA.Focus();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btcalcular_Click(object sender, EventArgs e)
        {
            double A1, b1, c1, d1, resultado;

            A1 = Convert.ToDouble(TxtA.Text);
            b1 = Convert.ToDouble(Txtb.Text);
            c1 = Convert.ToDouble(Txtc.Text);
            d1 = Convert.ToDouble(Txtd.Text);


            resultado = (A1+b1)/(c1-d1);

            Txtresultado.Text = Convert.ToString(resultado);


        }

    }
}
