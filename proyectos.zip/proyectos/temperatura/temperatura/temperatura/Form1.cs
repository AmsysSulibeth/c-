﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace temperatura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            txt4.Clear();
            txt5.Clear();
            txt6.Clear();
            txtalto.Clear();
            txtmedio.Clear();
            txtbajo.Clear();
            txt1.Focus();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b, c, d, p, f, alta=0, media=0, baja=0;

            a = Convert.ToDouble(txt1.Text);
            b = Convert.ToDouble(txt2.Text);
            c = Convert.ToDouble(txt3.Text);
            d = Convert.ToDouble(txt4.Text);
            p = Convert.ToDouble(txt5.Text);
            f = Convert.ToDouble(txt6.Text);


            alta = (a += c);
            media = (b += d);
            baja = (p += f);

            txtalto.Text = Convert.ToString(alta);
            txtmedio.Text = Convert.ToString(media);
            txtbajo.Text = Convert.ToString(baja);

        }
    }
}
