﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hipitenusagrafica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btsalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btlimpiar_Click(object sender, EventArgs e)
        {
            txtcateto1.Clear();
            txtcateto2.Clear();
            txthipotenusa.Clear();
            txtcateto1.Focus();

        }

        private void btcalificar_Click(object sender, EventArgs e)
        {
            double hipotenusa, cateto1, cateto2;

            cateto1 = Convert.ToDouble(txtcateto1.Text);
            cateto2 = Convert.ToDouble(txtcateto2.Text);

            hipotenusa = ((cateto1 * cateto1) + (cateto2 * cateto2));

            txthipotenusa.Text = Convert.ToString(hipotenusa);
        }
    }
}
