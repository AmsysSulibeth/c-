﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace notas4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btlimpiar_Click(object sender, EventArgs e)
        {
            txtem1.Clear();
            txtem2.Clear();
            txtem3.Clear();
            txtem4.Clear();
            txte1.Clear();
            txte2.Clear();
            txte3.Clear();
            txte4.Clear();
            txte1.Focus();
        }

        private void btcalificar_Click(object sender, EventArgs e)
        {
            int e1, e2, e3, e4, em1, em2, em3, em4;


            e1 = int.Parse(txte1.Text); 
            e2 = int.Parse(txte2.Text);
            e3 = int.Parse(txte3.Text);
            e4 = int.Parse(txte4.Text);



            em1 = e1 * 4 / 2 / 2;
            em2 = e2 * 4 / 2 / 2;
            em3 = e3 * 4 / 2 / 2;
            em4 = e4 * 4 / 2 / 2;


            txtem1.Text = Convert.ToString(em1);
            txtem2.Text = Convert.ToString(em2);
            txtem3.Text = Convert.ToString(em3);
            txtem4.Text = Convert.ToString(em4);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
