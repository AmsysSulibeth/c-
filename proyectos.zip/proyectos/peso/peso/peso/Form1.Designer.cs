﻿namespace peso
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txt8 = new System.Windows.Forms.TextBox();
            this.txt7 = new System.Windows.Forms.TextBox();
            this.txt5 = new System.Windows.Forms.TextBox();
            this.txt10 = new System.Windows.Forms.TextBox();
            this.txt9 = new System.Windows.Forms.TextBox();
            this.txt6 = new System.Windows.Forms.TextBox();
            this.txt11 = new System.Windows.Forms.TextBox();
            this.txt4 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txt19 = new System.Windows.Forms.TextBox();
            this.txt18 = new System.Windows.Forms.TextBox();
            this.txt17 = new System.Windows.Forms.TextBox();
            this.txt16 = new System.Windows.Forms.TextBox();
            this.txt12 = new System.Windows.Forms.TextBox();
            this.txt13 = new System.Windows.Forms.TextBox();
            this.txt14 = new System.Windows.Forms.TextBox();
            this.txt15 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.dgv_numero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_matric = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tgv_nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_edad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_estatu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_peso = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_imc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_contes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero:";
            // 
            // txt1
            // 
            this.txt1.BackColor = System.Drawing.Color.RosyBrown;
            this.txt1.Location = new System.Drawing.Point(125, 82);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(22, 20);
            this.txt1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(161, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Matricula:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(421, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "Alumno:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(50, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Fecha De Nacimiento:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(320, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "Edad:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(429, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "Libras:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(51, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 19);
            this.label7.TabIndex = 7;
            this.label7.Text = "Peso a KG:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(247, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 19);
            this.label8.TabIndex = 8;
            this.label8.Text = "Pies:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(373, 160);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 19);
            this.label9.TabIndex = 9;
            this.label9.Text = "Pulgadas:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(386, 205);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 19);
            this.label10.TabIndex = 10;
            this.label10.Text = "Contextura:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(271, 206);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 19);
            this.label11.TabIndex = 11;
            this.label11.Text = "IMC:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(51, 206);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 19);
            this.label12.TabIndex = 12;
            this.label12.Text = "Estatura en metros:";
            // 
            // txt8
            // 
            this.txt8.BackColor = System.Drawing.Color.RosyBrown;
            this.txt8.Location = new System.Drawing.Point(481, 206);
            this.txt8.Name = "txt8";
            this.txt8.Size = new System.Drawing.Size(61, 20);
            this.txt8.TabIndex = 14;
            // 
            // txt7
            // 
            this.txt7.BackColor = System.Drawing.Color.RosyBrown;
            this.txt7.Location = new System.Drawing.Point(324, 204);
            this.txt7.Name = "txt7";
            this.txt7.Size = new System.Drawing.Size(47, 20);
            this.txt7.TabIndex = 15;
            // 
            // txt5
            // 
            this.txt5.BackColor = System.Drawing.Color.RosyBrown;
            this.txt5.Location = new System.Drawing.Point(198, 207);
            this.txt5.Name = "txt5";
            this.txt5.Size = new System.Drawing.Size(55, 20);
            this.txt5.TabIndex = 16;
            // 
            // txt10
            // 
            this.txt10.BackColor = System.Drawing.Color.RosyBrown;
            this.txt10.Location = new System.Drawing.Point(453, 161);
            this.txt10.Name = "txt10";
            this.txt10.Size = new System.Drawing.Size(89, 20);
            this.txt10.TabIndex = 17;
            // 
            // txt9
            // 
            this.txt9.BackColor = System.Drawing.Color.RosyBrown;
            this.txt9.Location = new System.Drawing.Point(295, 161);
            this.txt9.Name = "txt9";
            this.txt9.Size = new System.Drawing.Size(59, 20);
            this.txt9.TabIndex = 18;
            // 
            // txt6
            // 
            this.txt6.BackColor = System.Drawing.Color.RosyBrown;
            this.txt6.Location = new System.Drawing.Point(143, 161);
            this.txt6.Name = "txt6";
            this.txt6.Size = new System.Drawing.Size(77, 20);
            this.txt6.TabIndex = 19;
            // 
            // txt11
            // 
            this.txt11.BackColor = System.Drawing.Color.RosyBrown;
            this.txt11.Location = new System.Drawing.Point(492, 119);
            this.txt11.Name = "txt11";
            this.txt11.Size = new System.Drawing.Size(50, 20);
            this.txt11.TabIndex = 20;
            // 
            // txt4
            // 
            this.txt4.BackColor = System.Drawing.Color.RosyBrown;
            this.txt4.Location = new System.Drawing.Point(371, 118);
            this.txt4.Name = "txt4";
            this.txt4.Size = new System.Drawing.Size(30, 20);
            this.txt4.TabIndex = 21;
            // 
            // txt3
            // 
            this.txt3.BackColor = System.Drawing.Color.RosyBrown;
            this.txt3.Location = new System.Drawing.Point(492, 84);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(190, 20);
            this.txt3.TabIndex = 22;
            // 
            // txt2
            // 
            this.txt2.BackColor = System.Drawing.Color.RosyBrown;
            this.txt2.Location = new System.Drawing.Point(251, 82);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(160, 20);
            this.txt2.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(232, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(243, 24);
            this.label13.TabIndex = 24;
            this.label13.Text = "Medidor de masa corporal";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(574, 143);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 36);
            this.button1.TabIndex = 26;
            this.button1.Text = "Enviar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(524, 476);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(144, 36);
            this.button2.TabIndex = 27;
            this.button2.Text = "Limpiar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(317, 442);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 22);
            this.label14.TabIndex = 28;
            this.label14.Text = "Promedios";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(206, 442);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 22);
            this.label15.TabIndex = 29;
            this.label15.Text = "Totales";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(62, 442);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 22);
            this.label16.TabIndex = 30;
            this.label16.Text = "Contexturas";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(72, 575);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(71, 19);
            this.label25.TabIndex = 39;
            this.label25.Text = "Obesidad:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(72, 540);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 19);
            this.label26.TabIndex = 40;
            this.label26.Text = "Sobre Peso:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(72, 507);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(63, 19);
            this.label27.TabIndex = 41;
            this.label27.Text = "Delgado:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(72, 476);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(58, 19);
            this.label28.TabIndex = 42;
            this.label28.Text = "Normal:";
            // 
            // txt19
            // 
            this.txt19.BackColor = System.Drawing.Color.RosyBrown;
            this.txt19.Location = new System.Drawing.Point(321, 563);
            this.txt19.Name = "txt19";
            this.txt19.Size = new System.Drawing.Size(77, 20);
            this.txt19.TabIndex = 44;
            // 
            // txt18
            // 
            this.txt18.BackColor = System.Drawing.Color.RosyBrown;
            this.txt18.Location = new System.Drawing.Point(321, 537);
            this.txt18.Name = "txt18";
            this.txt18.Size = new System.Drawing.Size(77, 20);
            this.txt18.TabIndex = 45;
            // 
            // txt17
            // 
            this.txt17.BackColor = System.Drawing.Color.RosyBrown;
            this.txt17.Location = new System.Drawing.Point(321, 506);
            this.txt17.Name = "txt17";
            this.txt17.Size = new System.Drawing.Size(77, 20);
            this.txt17.TabIndex = 46;
            // 
            // txt16
            // 
            this.txt16.BackColor = System.Drawing.Color.RosyBrown;
            this.txt16.Location = new System.Drawing.Point(321, 475);
            this.txt16.Name = "txt16";
            this.txt16.Size = new System.Drawing.Size(77, 20);
            this.txt16.TabIndex = 47;
            // 
            // txt12
            // 
            this.txt12.BackColor = System.Drawing.Color.RosyBrown;
            this.txt12.Location = new System.Drawing.Point(201, 475);
            this.txt12.Name = "txt12";
            this.txt12.Size = new System.Drawing.Size(77, 20);
            this.txt12.TabIndex = 51;
            // 
            // txt13
            // 
            this.txt13.BackColor = System.Drawing.Color.RosyBrown;
            this.txt13.Location = new System.Drawing.Point(201, 506);
            this.txt13.Name = "txt13";
            this.txt13.Size = new System.Drawing.Size(77, 20);
            this.txt13.TabIndex = 50;
            // 
            // txt14
            // 
            this.txt14.BackColor = System.Drawing.Color.RosyBrown;
            this.txt14.Location = new System.Drawing.Point(201, 537);
            this.txt14.Name = "txt14";
            this.txt14.Size = new System.Drawing.Size(77, 20);
            this.txt14.TabIndex = 49;
            // 
            // txt15
            // 
            this.txt15.BackColor = System.Drawing.Color.RosyBrown;
            this.txt15.Location = new System.Drawing.Point(201, 563);
            this.txt15.Name = "txt15";
            this.txt15.Size = new System.Drawing.Size(77, 20);
            this.txt15.TabIndex = 48;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(524, 413);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(144, 36);
            this.button3.TabIndex = 52;
            this.button3.Text = "Consultar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(524, 553);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(144, 36);
            this.button4.TabIndex = 53;
            this.button4.Text = "Salir";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.RosyBrown;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.RosyBrown;
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.RosyBrown;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(214, 120);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(94, 20);
            this.dateTimePicker1.TabIndex = 54;
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(47, 398);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(412, 223);
            this.groupBox1.TabIndex = 55;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Estadistica";
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToDeleteRows = false;
            this.dgv1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgv_numero,
            this.dgv_matric,
            this.tgv_nombre,
            this.dgv_edad,
            this.dgv_estatu,
            this.dgv_peso,
            this.dgv_imc,
            this.dgv_contes});
            this.dgv1.Location = new System.Drawing.Point(47, 251);
            this.dgv1.Name = "dgv1";
            this.dgv1.ReadOnly = true;
            this.dgv1.Size = new System.Drawing.Size(653, 120);
            this.dgv1.TabIndex = 56;
            // 
            // dgv_numero
            // 
            this.dgv_numero.HeaderText = "Numero del estudiante";
            this.dgv_numero.Name = "dgv_numero";
            this.dgv_numero.ReadOnly = true;
            // 
            // dgv_matric
            // 
            this.dgv_matric.HeaderText = "Matricula";
            this.dgv_matric.Name = "dgv_matric";
            this.dgv_matric.ReadOnly = true;
            // 
            // tgv_nombre
            // 
            this.tgv_nombre.HeaderText = "Nombre del estuduante";
            this.tgv_nombre.Name = "tgv_nombre";
            this.tgv_nombre.ReadOnly = true;
            // 
            // dgv_edad
            // 
            this.dgv_edad.HeaderText = "Edad";
            this.dgv_edad.Name = "dgv_edad";
            this.dgv_edad.ReadOnly = true;
            // 
            // dgv_estatu
            // 
            this.dgv_estatu.HeaderText = "Estatura";
            this.dgv_estatu.Name = "dgv_estatu";
            this.dgv_estatu.ReadOnly = true;
            // 
            // dgv_peso
            // 
            this.dgv_peso.HeaderText = "Peso";
            this.dgv_peso.Name = "dgv_peso";
            this.dgv_peso.ReadOnly = true;
            // 
            // dgv_imc
            // 
            this.dgv_imc.HeaderText = "IMC";
            this.dgv_imc.Name = "dgv_imc";
            this.dgv_imc.ReadOnly = true;
            // 
            // dgv_contes
            // 
            this.dgv_contes.HeaderText = "Contextura";
            this.dgv_contes.Name = "dgv_contes";
            this.dgv_contes.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(739, 654);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.txt19);
            this.Controls.Add(this.txt18);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.txt17);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txt16);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt14);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt13);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt12);
            this.Controls.Add(this.txt4);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.txt11);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.txt6);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txt9);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.txt10);
            this.Controls.Add(this.txt5);
            this.Controls.Add(this.txt7);
            this.Controls.Add(this.txt8);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt8;
        private System.Windows.Forms.TextBox txt7;
        private System.Windows.Forms.TextBox txt5;
        private System.Windows.Forms.TextBox txt10;
        private System.Windows.Forms.TextBox txt9;
        private System.Windows.Forms.TextBox txt6;
        private System.Windows.Forms.TextBox txt11;
        private System.Windows.Forms.TextBox txt4;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txt19;
        private System.Windows.Forms.TextBox txt18;
        private System.Windows.Forms.TextBox txt17;
        private System.Windows.Forms.TextBox txt16;
        private System.Windows.Forms.TextBox txt12;
        private System.Windows.Forms.TextBox txt13;
        private System.Windows.Forms.TextBox txt14;
        private System.Windows.Forms.TextBox txt15;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_numero;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_matric;
        private System.Windows.Forms.DataGridViewTextBoxColumn tgv_nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_edad;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_estatu;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_peso;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_imc;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_contes;
    }
}

